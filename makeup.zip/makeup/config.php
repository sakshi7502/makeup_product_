<?php
error_reporting(E_ALL & ~E_NOTICE);
$host = '127.0.0.1';
$dbname = 'onlineshop';
$user = 'root';
$password = '';

?>