<?php
include("config/db.php");
session_start();
include("session.php");
unset($_SESSION['firstname']);
header("Location:index.php")
?>